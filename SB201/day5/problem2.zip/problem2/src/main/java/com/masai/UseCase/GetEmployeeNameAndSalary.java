package com.masai.UseCase;

public class GetEmployeeNameAndSalary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
