package com.masai.UseCase;

public class GetEmployeeSalaryById {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
