package com.masai.UseCase;

public class GetEmployeesByAddress {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
