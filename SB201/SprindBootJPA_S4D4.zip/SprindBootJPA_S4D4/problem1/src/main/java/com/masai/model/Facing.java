package com.masai.model;

public enum Facing {
	East,West,North,South
}
