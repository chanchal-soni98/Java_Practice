package com.masai;

import org.springframework.stereotype.Component;

@Component
public class Bike {
	
	public void ride() {
		System.out.println("Lets ride..");
	}

}
