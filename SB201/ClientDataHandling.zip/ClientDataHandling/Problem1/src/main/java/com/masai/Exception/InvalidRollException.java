package com.masai.Exception;

public class InvalidRollException extends RuntimeException{
	
	public InvalidRollException() {
		
	}
	public InvalidRollException(String message) {
		super(message);
	}
}
